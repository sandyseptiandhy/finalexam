package id.co.skyforce.shop.model;

public enum CustomerSession {
	LOGGEDIN, LOGGEDOUT
}
