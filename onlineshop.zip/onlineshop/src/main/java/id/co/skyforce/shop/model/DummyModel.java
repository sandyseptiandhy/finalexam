package id.co.skyforce.shop.model;

public class DummyModel {

}
